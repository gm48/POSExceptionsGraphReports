"use strict";
try {
    var require = {
        baseUrl: './'
        , paths: {
            'global': '../app/global'
            , 'jquery': '../lib/jquery/jquery-3.3.1.min'
            , 'knockout': '../lib/knockout/knockout-3.4.2.min'
            , 'jquery-ui': '../style/jquery-ui-1.11.4/jquery-ui.min'
            , 'blockUI': '../lib/jquery/jquery.blockui'
            , 'chart': '../lib/Chart.js-2.6.0/Chart-2.6.0-g.bundle'  
            , 'bootstrap': '../style/bootstrap-3.3.1/dist/js/bootstrap.min'
            , 'bootstrap-multiselect': '../style/bootstrap-multiselect/bootstrap-multiselect'

            , 'xml2json': '../app/tool-util/xtras/xml2json'
            , 'ko-ext': '../app/tool-util/xtras/ko-ext'
            , 'js-ko-xtra': '../app/tool-util/xtras/js-ko-xtra'

            , 'plugin': '../app/exec-srvs/plugin'
            , 'interop': '../app/exec-srvs/interop'
            , 'xec-call': '../app/exec-srvs/xec-call'
            , 'serviceHub': '../app/db-log/serviceHub'

            , 'meta-static': '../app/objects/meta-static'
            , 'meta-sp': '../app/objects/meta-sp'
            , 'objects': '../app/objects/'

            , 'core-ui': '../app/core/ui-hub'
            , 'chart-ext': '../app/tool-util/xtras/chart-ext'
            , 'chart-core': '../app/objects/chart-report/chart-core'
            , 'popup-table-map': '../app/objects/popup-table/popup-table-map'
        }
        , shim: {
            
            'jquery-ui': { deps: ['jquery'], exports: 'jquery-ui' }
            , 'bootstrap': { deps: ['jquery'], exports: 'bootstrap' }
            , 'bootstrap-multiselect': { deps: ['jquery', 'bootstrap', 'knockout'], exports: 'bootstrap-multiselect' }
            , 'ko-xtra': { deps: ['jquery', 'knockout'], exports: 'ko-xtra' }
            , 'chart-xtra': { deps: ['jquery', 'knockout', 'chart'], exports: 'chart-xtra' }   
            , 'serviceSupport': { deps: ['plugin', 'xec-call', 'serviceHub'], exports: 'serviceSupport' }
        }
    };
} catch (e) { alert(e.name + '\n var require = { \n' + e.message); }


"use strict";
define(["jquery"], function(e) {
    try {
        var n = function(n) {
            e(".-click-menu-").unbind(), e(".-click-menu-").click(function() {
                if(event.preventDefault(), e(this).hasClass("-block-click-")) return !1;
                try { n(e(this)[0].id)
                } catch(e) { return console.log(e.name + "\n" + e.message), !1 }
                return !0
            })
        }
    } catch(e) { console.log(e.name + "\n" + e.message) }
    return n
});





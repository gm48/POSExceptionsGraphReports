"use strict";
define(['plugin', 'xec-call'], function(plugin, xecCall) {
    try {
        var _TAG = 'serviceHub', exports = plugin.createPlugin(_TAG, { proc_json: function(_options, _fcallBack, _fcallBackError) { return (xecCall.xecCall('', '', _options, _fcallBack, _fcallBackError, 0)) } }
            );
    } catch(e) { console.log(_TAG + ':\n' + e.name + '\n' + e.message); }
    exports.register();
    return (exports);
});

define(["interop"], function(n) {
    return this.xecCall = function(r, e, t, u, i, o) {
        var s = {
            parameters: t.parameters,
            url: t.url,
            success: function(n) {  u(n) },
            error: null == i ? void 0 : function(n, r, e) { i(n, r, e) }
        };
        return n.invoke(s), null != u || response
    }, this
});
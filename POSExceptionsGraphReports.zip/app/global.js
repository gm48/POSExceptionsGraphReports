﻿"use strict";
define(function() {
    try {
        var $$$DEBUG = !1;
        String.prototype._cap1st = function() {
            return this.charAt(0).toUpperCase() + this.substr(1)
        }, Date.prototype._today = function() {
            var e = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"),
                t = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"),
                r = new Date;
            return e[r.getDay()] + ", " + t[r.getMonth()] + " " + r.getDate() + ", " + r.getFullYear()
        }, Date.prototype.withoutTime = function() {
            var e = new Date(this);
            return e.setHours(0, 0, 0, 0), e
        }, self.kFormatter = function(e) {
            return e > 999 ? (e / 1e3).toFixed(1) + "k" : e
        }, self.randomColor = function() {
            for(var e = "0123456789ABCDEF".split(""), t = "#", r = 0; r < 6; r++) t += e[Math.floor(16 * Math.random())];
            return t
        }, self.randomColorGenerator = function() {
            return "#" + (Math.random().toString(16) + "0000000").slice(2, 8)
        }, self._isDate = function(e) {
            return "" != e && new Date(e) instanceof Date
        }, self._dateShort_1 = function(e) {
            var t = new Date(e);
            t.setDate(t.getDate() + 1);
            var r = "" + (t.getMonth() + 1),
                a = "" + t.getDate(),
                n = t.getFullYear();
            return r.length < 2 && (r = "0" + r), a.length < 2 && (a = "0" + a), [r, a, n].join("/")
        }, self._dateShort = function(e) {
            var t = new Date(e),
                r = "" + (t.getMonth() + 1),
                a = "" + t.getDate(),
                n = t.getFullYear();
            return r.length < 2 && (r = "0" + r), a.length < 2 && (a = "0" + a), [r, a, n].join("/")
        }, self.date_diff_indays = function(e, t) {
            var r = new Date(e),
                a = new Date(t);
            return Math.floor((Date.UTC(a.getFullYear(), a.getMonth(), a.getDate()) - Date.UTC(r.getFullYear(), r.getMonth(), r.getDate())) / 864e5)
        }
    } catch(e) {
        console.log("global.js \n" + e.name + "\n" + e.message)
    }
    return self
});



//  ftps://waws-prod-blu-073.ftp.azurewebsites.windows.net/site/wwwroot
//  XListReports\$XListReports
//  6XZcJhlb4zf93Tj55uPHSpFRJ01McJZFSJYl1Qb8Fc4XLSN2JQ3hFosfNEgD
//  XListReports
//  https://xlistreports.azurewebsites.net

//  ftps://waws-prod-blu-073.ftp.azurewebsites.windows.net/site/wwwroot
//  xlistmultisitereports\$xlistmultisitereports
//  Zrgq1TvGipvDR6jZeX34jlzZsW3DEo7MvNJ58QXcSFTuaeBkD4Mn99bS67ho
//  xlistmultisitereports
//  https://xlistmultisitereports.azurewebsites.net
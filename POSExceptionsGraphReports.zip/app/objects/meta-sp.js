﻿//  "use strict";
define(['jquery', 'knockout'], function($, ko) {
    var $$$DEBUG = !1, _tag = 'objects.meta-sp', _lnum = 0, self = this;
    try {
        function __values_quotes(s) {
            if(!s || undefined) { s = '' };
            s = s.toString();
            var _re = s.substr(0, s.length).substr(0).split(',').map(function(x) {
                return "'" + x + "'";
            }).toString();
            return _re;  //  s.substr(0, s.length).substr(0).split(',').map(x => "'" + x + "'").toString();
        }

        self.rep_defaults = {
            report_name: 'Exceptions_Count_By_DVR_By_Date'
            , data: {}
            , Xname: ''
            , Yname: ''
            , alltips: !0
            , type: 'line'
            , point_fnc: function(a, b, c) { ; }
            , table_array2push: []
        };

        self.__sp_POSExceptionsGraphReports = function(
            procedure_name, action, actionType, sub_action, file_date_from, file_date_to, Title, ExceptionName
                , CashierID, DateTimeStamp_from, DateTimeStamp_to, Trans, Port, IP)
        {
            if(!procedure_name) { procedure_name = 'dbo.__sp_POSExceptionsGraphReports'}
            return [
                '@procedure_name ' + procedure_name
                , '@action ' + action
                , '@actionType ' + actionType
                , '@sub_action ' + sub_action
                , '@file_date_from ' + _dateShort(file_date_from)
                , '@file_date_to ' + _dateShort(file_date_to)
                , '@Title ' + __values_quotes(Title)
                , '@ExceptionName ' + __values_quotes(ExceptionName)
                , '@CashierID ' + __values_quotes(CashierID)
                , '@DateTimeStamp_from ' + DateTimeStamp_from
                , '@DateTimeStamp_to ' + DateTimeStamp_to
                , '@Trans ' + Trans
                , '@Port ' + Port
                , '@IP ' + IP
            ];
        };	
        self.__sp_URL = function(procedure_name, action, actionType, sub_action, Report_Parent, Report, Title_Text, CashierID_Title, Date, Time_from, Time_to, ExceptionName) {
            if(!procedure_name) { procedure_name = 'dbo.__sp_URL' }
            return [
                '@procedure_name ' + procedure_name
                , '@action ' + action
                , '@actionType ' + actionType
                , '@sub_action ' + sub_action
                , '@Report_Parent ' + Report_Parent
                , '@Report ' + Report
                , '@Title_Text ' + Title_Text
                , '@CashierID_Title ' + CashierID_Title
                , '@Date ' + Date
                , '@Time_from ' + Time_from
                , '@Time_to ' + Time_to
                , '@ExceptionName ' + ExceptionName
            ];
        };
        self.__sp_exec_link_URL = function(p, E, e, T, r, R) {
            return p || (p = "link_url_storekeeper"),
                ["param " + p,
                "_IP_PORT " + E,
                "_DATETIME " + e,
                "_USER_NAME " + T,
                "_XLIST " + r,
                "_REF " + R]
        };

    } catch(e) { alert(e.name + '\n' + _tag + ' : _lnum : ' + _lnum + '\n' + e.message); }
    return (self);
});


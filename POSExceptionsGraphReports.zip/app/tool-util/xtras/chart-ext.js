﻿"use strict";
require(["chart"], function(o) {
    var t = o.Chart;
    try {
        t.plugins.register({
            id: "alwaysTooltips",
            beforeRender: function(o) {
                o.config.options.showAllTooltips && (o.pluginTooltips = [], o.config.data.datasets.forEach(function(i, n) {
                    o.getDatasetMeta(n).data.forEach(function(i, a) {
                        o.getDatasetMeta(n).hidden || o.pluginTooltips.push(new t.Tooltip({
                            _chart: o.chart,
                            _chartInstance: o,
                            _data: o.data,
                            _options: o.options.tooltips,
                            _active: [i]
                        }, o))
                    })
                }), o.options.tooltips.enabled = !1)
            },
            afterDraw: function(o, i) {
                if(o.config.options.showAllTooltips) {
                    if(!o.allTooltipsOnce) {
                        if(1 !== i) return;
                        o.allTooltipsOnce = !0
                    }
                    o.options.tooltips.enabled = !0, t.helpers.each(o.pluginTooltips, function(o) {
                        o.initialize(), o._options.bodyFontFamily = "Helvetica,Calibri,sans-serif"
                        , o._options.bodyFontSize = .02 * o._chart.height, o._options.bodyFontColor = "white"
                        , o._options.hoverBackgroundColor = "rgba(225, 0, 55, 0.7)", o._options.border = "1px solid #125215"
                        , o._options.yPadding = 4, o._options.xPadding = 6, o._options.backgroundColor = "#97A5B3"
                        , o.update(), o.pivot(), o.transition(i).draw()
                    }), o.options.tooltips.enabled = !1
                }
            }
        })
    } catch(o) {
        console.log(o.name + "\nchart-ext : Chart.plugins.register({ \n" + o.message)
    }
    return this
});
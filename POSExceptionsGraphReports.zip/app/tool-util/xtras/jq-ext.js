require(["jquery", "knockout"], function(t, e) {
    return t.fn.extend({
        disableAll: function(e) {
            return this.each(function() {
                var n = t(this);
                n.is("input, button, textarea, select") ? this.disabled = e : n.toggleClass("disabled", e)
            })
        }
    }), t.fn.extend({
        disable: function(t) {
            return this.each(function() {
                this.disabled = t
            })
        }
    }), this
});